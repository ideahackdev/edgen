<?php 
// This is the fallback template file if a template cannot be found. Currently it 
// will just include the page template as the default content structure.

require('template-page.php'); ?>