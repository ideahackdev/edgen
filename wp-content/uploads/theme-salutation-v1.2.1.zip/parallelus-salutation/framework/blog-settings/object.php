<?php


class blog_settings_object extends framework_object_ambassador_1 {

	function init () {
		/* nothing */
	}

}

?>